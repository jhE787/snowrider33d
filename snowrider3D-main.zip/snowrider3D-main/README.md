# snowrider3d
Use the arrow keys or `A, S, D` to move. Use `W` or the upp arrow to jump. Avoid obstacles by dodging them or going over them.
